if _G.CSR then return end

_G.CSR 			= _G.CSR or {}
CSR._path 		= ModPath
CSR._data_path 	= SavePath .. "CSR_data.txt"
CSR._data = {
	DLOC = true,
	AM_EXP = 1,
	AM_CASH = 1,
	AM_COINS = 1,
	AM_LOOT = 1,
	AM_COSMETIC = 1
}

function CSR:Load()
	local file = io.open( self._data_path, "r" )
	if file then
		self._data = json.decode( file:read("*all") )
		file:close()
	end
end

function CSR:Save()
	local file = io.open( self._data_path, "w+" )
	if file then
		file:write( json.encode( self._data ) )
		file:close()
	end
end

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_CSR", function( loc )
	for _, filename in pairs(file.GetFiles(CSR._path .. "loc/")) do
		local str = filename:match('^(.*).txt$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			loc:load_localization_file(CSR._path .. "loc/" .. filename)
			break
		end
	end
	loc:load_localization_file( CSR._path .. 'loc/english.txt', false )	
end)

Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_CSR", function( menu_manager )

	MenuCallbackHandler.callback_dloc_choice = function(self, item)
		CSR._data.DLOC = (item:value() == "on" and true or false)
		CSR:Save()
	end
	MenuCallbackHandler.callback_experience_choice = function(self, item)
		CSR._data.AM_EXP = item:value()
		CSR:Save()
	end	
	MenuCallbackHandler.callback_cash_choice = function(self, item)
		CSR._data.AM_CASH = item:value()
		CSR:Save()
	end
	MenuCallbackHandler.callback_coins_choice = function(self, item)
		CSR._data.AM_COINS = item:value()
		CSR:Save()
	end
	MenuCallbackHandler.callback_loot_choice = function(self, item)
		CSR._data.AM_LOOT = item:value()
		CSR:Save()
	end
	MenuCallbackHandler.callback_cosmetic_choice = function(self, item)
		CSR._data.AM_COSMETIC = item:value()
		CSR:Save()
	end
	CSR:Load()
	MenuHelper:LoadFromJsonFile( CSR._path .. 'lua/settings.json', CSR, CSR._data )
end)

CSR:Load()

function CSR:Main(self)

	local amount_count_experience = CSR._data.AM_EXP * 125000
	local amount_count_cash = CSR._data.AM_CASH * 200000
	local amount_count_coins = CSR._data.AM_COINS * 0.3
	local amount_count_loot = CSR._data.AM_LOOT * 0.2
	local amount_count_cosmetic = CSR._data.AM_COSMETIC * 0.125
	
	if CSR._data.DLOC == true then
		self.crash_causes_loss = false
	end
	
	self.rewards = {
		{
			id = "experience",
			always_show = true,
			max_cards = 10,
			card_inc = 200000,
			name_id = "menu_challenge_xp_drop",
			icon = "upcard_xp",
			amount = amount_count_experience
		},
		{
			id = "cash",
			max_cards = 10,
			cash_string = "$",
			card_inc = 4000000,
			name_id = "menu_challenge_cash_drop",
			icon = "upcard_cash",
			always_show = true,
			amount = amount_count_cash
		},
		{
			id = "continental_coins",
			max_cards = 5,
			card_inc = 4,
			name_id = "menu_cs_coins",
			icon = "upcard_coins",
			amount = amount_count_coins
		},
		{
			id = "loot_drop",
			max_cards = 10,
			card_inc = 5,
			name_id = "menu_challenge_loot_drop",
			icon = "upcard_random",
			amount = amount_count_loot
		},
		{
			id = "random_cosmetic",
			max_cards = 10,
			card_inc = 5,
			name_id = "menu_challenge_cosmetic_drop",
			icon = "upcard_cosmetic",
			amount = amount_count_cosmetic
		}
	}
	self.all_cosmetics_reward = {
		amount = amount_count_cosmetic,
		type = "random_cosmetic"
	}
	
end

Hooks:PostHook(CrimeSpreeTweakData, "init", "CSR_newinit", function(self, tweak_data)
	CSR:Main(self)
end)